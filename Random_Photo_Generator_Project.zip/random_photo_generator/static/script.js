const button = document.getElementById("get-photo");
const photo = document.getElementById("photo");
const title = document.getElementById("photo-title");
const category = document.getElementById("category");

async function getRandomPhoto() {
  button.disabled = true;
  button.querySelector("span:first-child").textContent = "Loading...";
  photo.classList.add("loading");

  try {
    const response = await fetch("/api/random-photo");
    if (!response.ok) throw new Error("Could not load a photo");
    const data = await response.json();

    const nextImage = new Image();
    nextImage.onload = () => {
      photo.src = data.url;
      photo.alt = data.title;
      title.textContent = data.title;
      category.textContent = data.category.toUpperCase();
      photo.classList.remove("loading");
      button.disabled = false;
      button.querySelector("span:first-child").textContent = "Get Photo";
    };
    nextImage.onerror = () => {
      photo.classList.remove("loading");
      button.disabled = false;
      button.querySelector("span:first-child").textContent = "Get Photo";
      alert("The photo could not be loaded. Please try again.");
    };
    nextImage.src = data.url;
  } catch (error) {
    photo.classList.remove("loading");
    button.disabled = false;
    button.querySelector("span:first-child").textContent = "Get Photo";
    alert("Something went wrong. Please try again.");
  }
}

button.addEventListener("click", getRandomPhoto);
